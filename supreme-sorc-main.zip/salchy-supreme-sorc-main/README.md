# salchy-supreme-sorc

Free version of supreme sorc. Ill update it the following weeks.

Use lighting trap to cast elemental fusion/prime fusion (it will auto cast depending on CDs)
Tap arcane pulse
Insta hit boss with projectile skills
Auto cast ice lances with nova & arcane pulse
